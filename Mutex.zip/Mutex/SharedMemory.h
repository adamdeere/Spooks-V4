#pragma once

#include <iostream>
#include <windows.h>
using namespace std;

class SharedMemory
{
private:
	int _data;
	//HANDLE _mutex;

public:
	SharedMemory(void);
	~SharedMemory(void);

	//bool Acquire() const {
	//	return (WaitForSingleObject(_mutex,500L) == WAIT_OBJECT_0);
	//}

	//void Release() const {
	//	ReleaseMutex(_mutex);
	//}

	void setData(int data);
	int getData();
};
