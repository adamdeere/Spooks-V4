#include ".\Consumer.h"
#include "ThreadSafeRandom.h"

unsigned __stdcall Consumer::consume(void *context) {
	Consumer *cons = (Consumer*)context;
	int sum = 0;
	for(int n = 0; n < 8; n++)	{
		//Sleep((rand()*4000)/RAND_MAX);
		Sleep((ThreadSafeRandom::rand()*4000)/RAND_MAX);

		int data = cons->_shared->getData();
		cout << "Reading " << data << endl;
		sum += data;
	}
	cout << "Sum = " << sum << endl;

	return 0;
}
