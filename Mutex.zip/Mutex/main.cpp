
#include <windows.h>
#include <process.h>
#include <time.h>
#include "SharedMemory.h"
#include "Producer.h"
#include "Consumer.h"

void main(int, char**)
{
	cout << "Main Begin" << endl;

	//srand(clock());

	SharedMemory shared;

	Producer prod(&shared);
	Consumer cons(&shared);

	unsigned threadIdA=0, threadIdB=0;
	HANDLE hThreadA = (HANDLE)_beginthreadex(
		NULL,		// no security attributes (child cannot inherited handle)
		1024*1024,	// 1MB stack size
		prod.produce,	// code to run on new thread
		&prod,		// pointer to host application class
		0,			// run immediately (could create suspended)
		&threadIdA	// OUT: returns thread ID
	);
	HANDLE hThreadB = (HANDLE)_beginthreadex(
		NULL,		// no security attributes (child cannot inherited handle)
		1024*1024,	// 1MB stack size
		cons.consume,	// code to run on new thread
		&cons,		// pointer to host application class
		0,			// run immediately (could create suspended)
		&threadIdB	// OUT: returns thread ID
	);

	cout << "Threads Created" << endl;
  
	WaitForSingleObject( hThreadA, INFINITE );
	CloseHandle( hThreadA );
	WaitForSingleObject( hThreadB, INFINITE );
	CloseHandle( hThreadB );

	cout << "Main End" << endl;

}
