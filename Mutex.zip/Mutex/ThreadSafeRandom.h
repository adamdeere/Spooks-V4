#pragma once
#include <windows.h>
#include <iostream>
using namespace std;

class ThreadSafeRandom
{
	CRITICAL_SECTION _cs;

	int generate();
	ThreadSafeRandom();

public:
	~ThreadSafeRandom();

	static int rand();
};

