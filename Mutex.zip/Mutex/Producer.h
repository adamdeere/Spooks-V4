#pragma once

#include <iostream>
#include <windows.h>
#include <process.h>
#include "SharedMemory.h"
using namespace std;


class Producer {
private:
	SharedMemory *_shared;

public:
	Producer() : _shared(NULL) {}
	Producer(SharedMemory *shared) : _shared(shared) {}

	static unsigned __stdcall produce(void *context);
};
