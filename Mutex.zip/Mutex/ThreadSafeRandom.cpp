#include "ThreadSafeRandom.h"
#include <time.h>

ThreadSafeRandom::ThreadSafeRandom() {
	srand(clock());
	InitializeCriticalSection(&_cs);
}

int ThreadSafeRandom::generate() {
	EnterCriticalSection(&_cs);
	int random = ::rand();
	LeaveCriticalSection(&_cs);
	return random;
}

ThreadSafeRandom::~ThreadSafeRandom() {
	DeleteCriticalSection(&_cs);
}

int ThreadSafeRandom::rand() {
	static ThreadSafeRandom instance;
	return instance.generate();
}
