#include ".\sharedmemory.h"

SharedMemory::SharedMemory() {
	_data = 0;
	//_mutex=CreateMutex(NULL,FALSE,"myMutex");
}

SharedMemory::~SharedMemory() {
	//CloseHandle(_mutex);
}

void SharedMemory::setData(int data) {
	_data = data;			   
}

int SharedMemory::getData() {
	return _data;
}