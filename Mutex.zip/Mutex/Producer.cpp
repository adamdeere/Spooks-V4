#include ".\Producer.h"
#include "ThreadSafeRandom.h"

unsigned __stdcall Producer::produce(void *context) {
	Producer *proc = (Producer*)context;
	for(int n = 0; n < 8; n++)
	{
		//Sleep((rand()*4000)/RAND_MAX);
		Sleep((ThreadSafeRandom::rand()*4000)/RAND_MAX);

		proc->_shared->setData(n);
		cout << "Writing " << n << endl;
	}

	return 0;
}
