#pragma once

#include <iostream>
#include <windows.h>
#include <process.h>
#include "SharedMemory.h"
using namespace std;


class Consumer {
private:
	SharedMemory *_shared;

public:
	Consumer() : _shared (NULL) {}
	Consumer(SharedMemory *shared) : _shared(shared) {}

	static unsigned __stdcall consume(void *context);
};
